#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

void cleanup(void) {
   printf("cleaning up\n");
}

void main() {
   atexit(cleanup);
   fork();
   exit(0);
}
