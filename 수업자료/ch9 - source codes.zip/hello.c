#include <stdio.h>
//#include <unistd.h>

int main()
{
    //write(1, "hello, world\n", 13);
    printf("hello, world\n");
    //_exit(0);
    return 0;
}