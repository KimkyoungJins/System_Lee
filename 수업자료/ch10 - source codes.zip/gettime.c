#include <stdio.h>
#include <sys/time.h>

int main() {
    struct timeval start, end;
    double elapsed = 0;

    gettimeofday(&start, NULL);

    for (long i = 0; i < 10000000; i++);

    gettimeofday(&end, NULL);

    printf("Start: seconds=%ld useconds=%ld\n", (long)start.tv_sec, (long)start.tv_usec);
    printf("End: seconds=%ld useconds=%ld\n", (long)start.tv_sec, (long)start.tv_usec);

    elapsed = (end.tv_sec - start.tv_sec) * 1000.0; 
    elapsed += (end.tv_usec - start.tv_usec) / 1000.0;   
    printf("Elapsed: %.6f ms\n", elapsed);
    
    return 0;
}