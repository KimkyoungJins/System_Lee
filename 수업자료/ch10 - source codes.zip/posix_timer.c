#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <string.h>
#include <unistd.h>

// Signal handler for timer expiration
void timer_handler(int sig) {
    if (sig == SIGALRM) {
        printf("Timer expired!\n");
    }
}

int main() {
    struct sigevent sev;
    struct itimerspec its;
    timer_t timerid;
    struct sigaction sa;

    // Set up the signal handler
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = timer_handler;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGALRM, &sa, NULL) == -1) {
        perror("sigaction");
        exit(EXIT_FAILURE);
    }

    // Create the timer
    sev.sigev_notify = SIGEV_SIGNAL;
    sev.sigev_signo = SIGALRM;
    sev.sigev_value.sival_ptr = &timerid;

    if (timer_create(CLOCK_REALTIME, &sev, &timerid) == -1) {
        perror("timer_create");
        exit(EXIT_FAILURE);
    }

    // Set the timer 
    its.it_value.tv_sec = 3;    // First expiration in 3 seconds
    its.it_value.tv_nsec = 0;
    its.it_interval.tv_sec = 2; // Interval of 2 seconds after that
    its.it_interval.tv_nsec = 0;

    if (timer_settime(timerid, 0, &its, NULL) == -1) {
        perror("timer_settime");
        exit(EXIT_FAILURE);
    }

    printf("Timer set. First 3 seconds, then every 2 seconds.\n");

    // Infinite loop waiting for the timer to expire
    while (1) {
        pause();  // Wait until a signal is received
    }

    // Delete the timer (won't actually be reached in this example)
    if (timer_delete(timerid) == -1) {
        perror("timer_delete");
        exit(EXIT_FAILURE);
    }

    return 0;
}
