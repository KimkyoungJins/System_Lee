#include <stdio.h>
#include <unistd.h>
#include <signal.h>

// Signal handler for timeout
void timeout(int sig)
{
    if (sig == SIGALRM)
        puts("Time out!");

    // generate SIGALRM after 2 seconds
    alarm(2); 	
}

// Signal handler for key control
void keycontrol(int sig)
{
    if (sig == SIGINT)
        puts("CTRL+C pressed");
}

int main(int argc, char *argv[])
{
    int i;
    signal(SIGALRM, timeout);   // for timeout
    signal(SIGINT, keycontrol); // for key control
    alarm(2);	// generate SIGALRM after 2 seconds

    for (i = 0; i < 3; i++)
    {
        puts("wait...");
        sleep(10);	// sleep for 10 seconds
    }
    return 0;
}
