#include <stdio.h>
#include <time.h>

int main() {
    struct timespec start, end;
    double elapsed = 0;

    clock_gettime(CLOCK_MONOTONIC, &start);

    for (long i = 0; i < 10000000; i++);
   
    clock_gettime(CLOCK_MONOTONIC, &end);

    printf("Start: seconds=%ld nanoseconds=%ld\n", (long)start.tv_sec, start.tv_nsec);
    printf("End: seconds=%ld nanoseconds=%ld\n", (long)end.tv_sec, end.tv_nsec);

    elapsed = (end.tv_sec - start.tv_sec) * 1000.0;        
    elapsed += (end.tv_nsec - start.tv_nsec) / 1000000.0;  
    printf("Elapsed: %.6f ms\n", elapsed);
   
    return 0;
}
