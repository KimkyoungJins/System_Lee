#include <stdio.h>
#include <time.h>
#include <unistd.h>  // sleep 함수 사용을 위해 필요

int main() {
    struct timespec start, end;
    double elapsed;

    // 시작 시간 측정
    clock_gettime(CLOCK_MONOTONIC, &start);

    // 측정할 코드 (예: 2초 대기)
    sleep(2);

    // 종료 시간 측정
    clock_gettime(CLOCK_MONOTONIC, &end);

    // 경과 시간 계산 (초와 나노초를 밀리초로 변환)
    elapsed = (end.tv_sec - start.tv_sec) * 1000.0;      // 초를 밀리초로 변환
    elapsed += (end.tv_nsec - start.tv_nsec) / 1000000.0; // 나노초를 밀리초로 변환

    printf("Elapsed time: %.2f ms\n", elapsed);
    return 0;
}
