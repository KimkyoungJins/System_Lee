
#include <stdio.h>

void huge_computing()
{
  printf("huge_computing\n");
  #if defined(FEATURE_X)
  #error "Feature X requires ENABLE_FEATURE_X to be defined."
  #endif

}

int main() {
    #ifdef _WIN32
    #error "This code cannot be compiled on Windows."
    #endif
#line 100 "main.c"
    printf("This code is %d in %s\n", __LINE__, __FILE__);
    huge_computing();
   
    return 0;
}

